<?php
$greetings = " Welcome to NG... ";
echo $greetings;