<?php
//session_start();
//require_once("../../login/session.php");
//include('../../login/db_connection_class.php');
//$obj = new DB_Connection_Class();
//$obj->connection();
//
//$s1 = 1;
////$sql_for_order = "SELECT * FROM orders ORDER BY order_id ASC";
//
//$sql_for_order = "
//                SELECT *, orders.order_id o_id from orders
//                 join buyer on buyer.buyer_id = orders.buyer_id
//                 ORDER BY orders.order_id ASC";
//$res_for_order = mysqli_query($con, $sql_for_order);
//
//while ($row = mysqli_fetch_assoc($res_for_order))
//{
//?>
<!---->
<!--<tr>-->
<!--    <td>--><?php //echo $s1; ?><!--</td>-->
<!--    <td>--><?php //echo $row['order_id']; ?><!--</td>-->
<!--    <td>--><?php //echo $row['buyer_delivery_date']; ?><!--</td>-->
<!--    <td>--><?php //echo $row['buyer_delivery_slot']; ?><!--</td>-->
<!--    <td>--><?php //echo $row['buyer_name']; ?><!--</td>-->
<!--    <td>--><?php //echo $row['fabric_qty']; ?><!--</td>-->
<!--    <td>--><?php //echo $row['color']; ?><!--</td>-->
<!--    <td>-->
<!---->
<!--        <button type="submit" id="edit_order" name="edit_order"  class="btn btn-primary btn-xs" onclick="load_page('settings/order/edit.php?order_id=--><?php //echo $row['o_id'] ?>//')"> Edit </button>
//        <span>  </span>
//        <button type="submit" id="delete_order" name="delete_order"  class="btn btn-danger btn-xs" onclick="load_page('settings/order/delete.php?order_id=<?php //echo $row['o_id'] ?>//')"> Delete </button>
//    </td>
//    <?php
//
//    $s1++;
//    }
//    ?>
<!---->
<!--</tr>-->
